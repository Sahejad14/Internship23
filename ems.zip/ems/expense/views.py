from django.shortcuts import render

from django.shortcuts import render
from django.views.generic.edit import CreateView
from expense.models import *
from django.views.generic import UpdateView, DeleteView,ListView
from .forms import*
# Create your views here.

class contactus_view(CreateView):
    model= contact
    form_class = contactus_form
    template_name='user/home/contact.html'
    success_url='/'

class ProjectUpdateView(UpdateView):
    model =  Expense
    form_class = ProjectCreationForm
    template_name = 'user/add.html'
    success_url = '/user/template/'

class ProjectDeleteView(DeleteView):
    model = Expense
    def get(self, request, *args, **kwargs):
        return self.delete(request, *args, **kwargs)
    
    success_url = '/user/template/'  

class contactus_view1(CreateView):
    model= contact
    form_class = contactus_form
    template_name='user/home/index.html'
    success_url='/'      
